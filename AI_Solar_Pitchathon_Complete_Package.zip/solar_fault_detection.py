"""
AI-Based Solar Panel Performance Monitoring and Fault Detection
Educational prototype: synthetic data is used unless --input-csv is supplied.
Expected optional CSV columns: timestamp, voltage_v, current_a, temperature_c, irradiance_wm2
Run: python solar_fault_detection.py
Run with real data: python solar_fault_detection.py --input-csv your_sensor_data.csv
Install: pip install -r requirements.txt
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

def make_demo_data(n=1200, seed=7):
    """Generate clearly synthetic panel readings for a repeatable software demo."""
    rng = np.random.default_rng(seed)
    timestamp = pd.date_range("2026-01-01", periods=n, freq="min")
    irradiance = np.clip(rng.normal(720, 180, n), 30, 1050)
    temperature = np.clip(rng.normal(38, 8, n), 15, 75)
    # Simplified educational relationship, not a PV manufacturer model.
    voltage = np.clip(30 - 0.035 * (temperature - 25) + rng.normal(0, 0.7, n), 20, 36)
    current = np.clip(8.5 * irradiance / 1000 + rng.normal(0, 0.22, n), 0.05, 10)
    fault = np.zeros(n, dtype=int)
    # Add several simulated abnormal intervals (reduced current / output).
    for start, length, factor in [(170, 55, 0.45), (480, 70, 0.25), (850, 60, 0.5), (1040, 35, 0.3)]:
        end = min(start + length, n)
        current[start:end] *= factor
        fault[start:end] = 1
    # One short sensor-like abnormal interval
    current[650:660] = 0.05
    fault[650:660] = 1
    return pd.DataFrame({
        "timestamp": timestamp, "voltage_v": voltage, "current_a": current,
        "temperature_c": temperature, "irradiance_wm2": irradiance,
        "label": fault
    })

def prepare(df):
    required = ["voltage_v", "current_a", "temperature_c"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError("CSV is missing required columns: " + ", ".join(missing))
    df = df.copy()
    for c in required + (["irradiance_wm2"] if "irradiance_wm2" in df.columns else []):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if "timestamp" not in df.columns:
        df["timestamp"] = pd.date_range("now", periods=len(df), freq="min")
    df["power_w"] = df["voltage_v"] * df["current_a"]
    # Rolling smoothing is causal: only current and earlier samples are used.
    df["power_smooth_w"] = df["power_w"].rolling(5, min_periods=1).mean()
    df["power_change_w"] = df["power_w"].diff().fillna(0)
    # Simple expected-output proxy. Irradiance improves this estimate when available.
    if "irradiance_wm2" in df.columns:
        df["expected_power_w"] = 30 * 8.5 * (df["irradiance_wm2"].clip(lower=0) / 1000)
    else:
        baseline = df["power_smooth_w"].rolling(60, min_periods=10).median()
        fallback = df["power_smooth_w"].median()
        df["expected_power_w"] = baseline.fillna(fallback).clip(lower=1)
    df["deviation_ratio"] = (
        (df["expected_power_w"] - df["power_smooth_w"]) /
        df["expected_power_w"].clip(lower=1)
    )
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", help="Optional sensor CSV file")
    args = parser.parse_args()
    if args.input_csv:
        raw = pd.read_csv(args.input_csv)
        is_synthetic = False
    else:
        raw = make_demo_data()
        is_synthetic = True
        print("NOTICE: using SYNTHETIC demo data, not real panel measurements.")
    df = prepare(raw)
    feature_cols = ["voltage_v", "current_a", "temperature_c", "power_w",
                    "power_smooth_w", "power_change_w", "deviation_ratio"]
    if "irradiance_wm2" in df.columns:
        feature_cols.append("irradiance_wm2")
    # Real CSV may not contain labels. Use transparent rule-based flags in that case.
    has_labels = "label" in df.columns and df["label"].notna().all()
    if has_labels and df["label"].nunique() >= 2:
        X = df[feature_cols].replace([np.inf, -np.inf], np.nan)
        y = df["label"].astype(int)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=y
        )
        model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("rf", RandomForestClassifier(n_estimators=150, random_state=42,
                                          class_weight="balanced"))
        ])
        model.fit(X_train, y_train)
        pred = model.predict(X)
        test_pred = model.predict(X_test)
        print("\\nEvaluation on held-out test split:")
        print(classification_report(y_test, test_pred, target_names=["normal", "possible_fault"], zero_division=0))
        cm = confusion_matrix(y_test, test_pred, labels=[0, 1])
        disp = ConfusionMatrixDisplay(cm, display_labels=["normal", "possible_fault"])
        disp.plot(values_format="d")
        plt.title("Confusion matrix — held-out synthetic/test data")
        plt.tight_layout()
        plt.savefig(OUT / "confusion_matrix.png", dpi=160)
        plt.close()
        df["predicted_fault"] = pred.astype(int)
        df["status"] = np.where(df["predicted_fault"] == 1, "INVESTIGATE", "NORMAL")
    else:
        # Fallback: conservative rule; requires several consecutive low-output samples.
        low = (df["deviation_ratio"] > 0.35) & (df["power_smooth_w"] > 1)
        df["predicted_fault"] = (low.rolling(5, min_periods=1).sum() >= 3).astype(int)
        df["status"] = np.where(df["predicted_fault"] == 1, "INVESTIGATE", "NORMAL")
        print("No two-class label column found; used a transparent rule-based detector.")
    df.to_csv(OUT / "solar_monitoring_results.csv", index=False)
    plt.figure(figsize=(11, 5))
    plt.plot(pd.to_datetime(df["timestamp"], errors="coerce"), df["power_w"], alpha=0.35, label="Raw power (W)")
    plt.plot(pd.to_datetime(df["timestamp"], errors="coerce"), df["power_smooth_w"], label="Smoothed power (W)")
    flagged = df["predicted_fault"] == 1
    if flagged.any():
        plt.scatter(pd.to_datetime(df.loc[flagged, "timestamp"], errors="coerce"),
                    df.loc[flagged, "power_smooth_w"], s=18, label="Flagged for investigation")
    plt.xlabel("Timestamp"); plt.ylabel("Power (W)")
    plt.title("Solar panel power monitoring — " + ("synthetic demo" if is_synthetic else "input CSV"))
    plt.legend(); plt.tight_layout()
    plt.savefig(OUT / "power_monitoring_plot.png", dpi=160)
    plt.close()
    print(f"Rows processed: {len(df)}")
    print(f"Rows flagged for investigation: {int(df['predicted_fault'].sum())}")
    print(f"Outputs saved in: {OUT.resolve()}")
    print("Reminder: an alert suggests inspection; it does not prove a specific physical fault.")

if __name__ == "__main__":
    main()
