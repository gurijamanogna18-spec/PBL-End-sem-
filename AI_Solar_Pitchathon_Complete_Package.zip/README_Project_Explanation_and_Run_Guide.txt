# AI-Based Solar Panel Performance Monitoring and Fault Detection

## Project explanation (simple)
A solar panel's output changes with sunlight, temperature, shading, dust and electrical problems. This project reads voltage, current and temperature (and optionally irradiance), calculates power using **P = V × I**, filters noisy measurements, compares output with a simple expected-output baseline, and flags readings that may need inspection.

### How the three subjects are used
- **Analog Electronic Circuit Design:** voltage divider / protection, current sensor, temperature sensor and optional RC low-pass filter before ADC acquisition.
- **Signal Processing:** sampling, smoothing, power calculation, trend/deviation features and removal of noisy fluctuations.
- **Machine Learning:** a Random Forest classifier learns from labelled normal/abnormal sample readings. If a supplied CSV has no valid two-class `label`, the script uses an explainable threshold rule instead.

## Important honesty note
The built-in dataset is **synthetic** for software demonstration. Its evaluation metrics do not prove real-world accuracy. For a physical prototype, calibrate sensors and collect labelled measurements from the actual panel. An alert means “investigate possible underperformance”; it cannot uniquely diagnose dust, shading, wiring or panel failure by itself.

## Run on Windows / VS Code
1. Install Python 3.10+ and make sure `python --version` works in VS Code terminal.
2. Open this folder in VS Code.
3. In terminal run:
   `python -m pip install -r requirements.txt`
4. Run:
   `python solar_fault_detection.py`
5. Check the `outputs` folder for:
   - `solar_monitoring_results.csv`
   - `power_monitoring_plot.png`
   - `confusion_matrix.png` (when labelled two-class data is available)

If `python` is not recognized, install Python from https://www.python.org/downloads/ and tick **Add Python to PATH**, then reopen VS Code.

## Use your own sensor CSV
Required columns: `voltage_v`, `current_a`, `temperature_c`. Optional: `timestamp`, `irradiance_wm2`, `label`.
- `label`: 0 = normal, 1 = abnormal/possible fault. Use only labels verified from your experiment.
- Example:
  `python solar_fault_detection.py --input-csv sensor_readings.csv`
Do not put mains/high-voltage PV wiring directly into a student circuit. Use suitable sensors, input protection, isolation where needed, and faculty supervision.

## Review presentation map
- Review 1: problem, objectives, architecture, subject mapping, feasibility and references.
- Review 2: acquisition, signal processing, analog front-end, ML, fault logic and test plan.
- Review 3: demo, metrics, interpretation, evaluation, limitations and future enhancements.

Replace blank team/guide fields on the title slides before uploading. The requested original sample PPT was not available as an attachment in this chat, so these decks use a consistent professional 16:9 format and the six-slide SIH-style flow as a reference, expanded to 7 slides per review.
